var webpack = require("webpack");
var path = require("path");

module.exports = {
    entry : './src/main.ts',
    output : {
        filename : './bundle.js'
    },
    resolve : { // 定义解析模块路径
        //root : [ path.join(__dirname, 'src') ],
        extensions : [ '.ts', '.js']
    },
    module : {
        loaders : [ 
            { test : /\.ts$/, loader : 'ts-loader' }
         ]
    }
};